## [0.1.2](https://github.com/xdy/twodsix-foundryvtt/compare/v4.24.5...v4.24.6) (2024-05-04)

### Bug Fixes
* Affichage de la difficulté pour les Talents Psioniques
* Ajout de scrollbar dans la feuille de personnage
* Drag & Drop sur la fiche des Carrières, Maladies, Contacts, Espèces
* Retrait du style sur les messages (le temps d'uniformiser les messages)
* Différents ajustements css

### Features
* Thème Bleu
* Amélioration du modèle Espèce
    * Ajout des champs : Description Détaillée, Modificateurs (tableau) et Traits (tableau)
* Lors du Drop d'une Espèce, copie des informations sur la fiche
* Ajout de la Durée pour les Talents Psioniques
* Bouton pour le jet de la Durée des Talents Psionique sur les messages
* Ajout de la difficulté sur la fenêtre des Jets
* Affichage du succès et de l'échec sur les messages