# MGT2 - Mongoose Traveller (Unofficial)

*English version below*

Ce système de jeu pour [Foundry Virtual Tabletop](http://foundryvtt.com) qui fournit une feuille de personnage et un système de jeu
pour Mongoose Publishing Traveller.

Spécialement développé pour la version française traduite par [Modül](https://www.gameontabletop.com/cf3161/traveller-vf.html)

#### Screenshots
![Alt text](https://raw.githubusercontent.com/JDR-Ninja/foundryvtt-mgt2/master/web/foundryvtt/inventory.jpg "Screenshot") 

## English
This game system for [Foundry Virtual Tabletop](http://foundryvtt.com) provides character sheet and game system 
support for Mongoose Publishing Traveller.

Specially developed for the French version translated by [Modül](https://www.gameontabletop.com/cf3161/traveller-vf.html)

